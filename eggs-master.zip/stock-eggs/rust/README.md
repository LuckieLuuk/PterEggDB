### Rust
The only aim in Rust is to survive. To do this you will need to overcome struggles such as hunger, thirst and cold. Build a fire. Build a shelter. Kill animals for meat. Protect yourself from other players, and kill them for meat. Create alliances with other players and form a town. Do whatever it takes to survive.

### Minimum RAM warning
The server requires at least 4096MB to run properly.
This is mostly needed for the startup only, once it is running (depending on your world size) it should consume less.

### Server Ports
Ports required to run the server.

| Port    | default |
|---------|---------|
| Game and Query | 28015 UDP |
| RCON | 28016 TCP |
| Rust+ App | 28082 TCP |
