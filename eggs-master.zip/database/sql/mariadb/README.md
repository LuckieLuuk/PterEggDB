# MariaDB
### From their [Website](https://mariadb.org/)
One of the most popular database servers. Made by the original developers of MySQL.  
Guaranteed to stay open source. 

### Minimum RAM warning
There is no actual minimum suggested for MariaDB.

See here https://mariadb.com/kb/en/library/mariadb-hardware-requirements/


### Server Ports
Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Server  |  3306   |
