# DragonProxy

A proxy to allow Minecraft: Bedrock clients to connect to Minecraft: Java Edition servers.

### Server Ports

DragonProxy need 2 port (default 19132)

| Port    | default  |
|---------|----------|
| Bind    | 19132    |
| Remote  | 25565    |

### Known Issues
Also see the [DragonProxy Github](https://github.com/DragonetMC/DragonProxy)
