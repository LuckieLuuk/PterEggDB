# Onset
From their [site](https://playonset.com/):  
Onset is an open world multiplayer sandbox without predefined goals. Create and host your very own experience in Onset using scripting functions. Whether that is Roleplay, Cops and Robbers or classic Freeroam. Or just enjoy the different gamemodes created by other players. 

## Recommended server settings
### RAM
This server requires about 100M to run.

See the following - https://dev.playonset.com/wiki/DedicatedServer#Minimum_requirements_2

### Disk
This server uses about 50M of disk.

## Server Ports

| Port  | default |
|-------|---------|
| Game  | 7777    |
| Query | 7776    |
| file  | 7775    |