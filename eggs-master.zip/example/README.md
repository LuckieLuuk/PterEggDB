# Example Server Name
### From their [Github](https://github.com/parkervcp/eggs)
A link to the site that you download game files from.  
The description of the server usually provided by the game/server maker.  

### Install notes
Due to rate limiting the console on the panel cannot keep up with the game console and the build will complete before the panel console may show it. Reloading the console will load it to the latest part of the log.

### Minimum RAM warning
Minimum required memory to run the server.


### Server Ports
Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 25565   |

#### Mods/Plugins may require ports to be added to the server.
