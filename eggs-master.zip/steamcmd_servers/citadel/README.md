# Citadel: Forged with fire
Citadel: Forged With Fire is a massive online sandbox RPG set in the mystical world of Ignus. Featuring magic, spellcasting, building, exploring and crafting as you fight to make a name for yourself and achieve notoriety across the land.

## Server Ports

| Port  | default |
|-------|---------|
| Game  | 7777    |
| Query | 27015   |

## Notes

You need to setup the Config of the Server in
/Config/Game.ini

-> WorldCreationSettings
