# JMusicBot
### Their [Github](https://github.com/jagrosh/MusicBot)
A Discord music bot that's easy to set up and run yourself! 

### Server Ports
There are no ports required for JMusicBot