---
name: "\U0001F3AE Game Request"
about: Suggest a server to build an egg for

---

Please fill out the information bellow and remove from the line up
Please understand how Pterodactyl works when you are requesting an egg. (ie. docker-compose doesn't work for a pterodactyl server)
---------------

Service: (Ex. minecraft/factorio/etc)

Does this expand an already existing service: Y/N

Link to game: (Ex. minecraft.net/factorio.com/etc)

Links for server downloads: This needs to be an official link and not one that is hosted on some forum page or a personal github page.

Links for install steps/docs:
