# SinusBot
### Their [Site](https://www.sinusbot.com/)
Listen to your favorite music together with all of your friends  

Welcome the Simple, Elegant & great sounding TS3- and Discord-Bot!  

### Server Ports
1 port is required to run SinusBot.

| Port    | default |
|---------|---------|
| Game    | 8087    |

### Side notes
This uses a custom image.