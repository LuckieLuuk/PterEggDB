# Red-DiscordBot
### From their [Github](https://github.com/Cog-Creators/Red-DiscordBot)
A multifunction Discord bot 

### Server Ports
No port are required to run Red.

### Additional Requirements
When using the Audio Cog the bot will attempt to save files to /tmp resulting in a disk space error.  To resolve this error you must increase the size of `tmpfs` using custom container policy.

For additional details see: https://pterodactyl.io/daemon/0.6/configuration.html#container-policy

#### Mods/Plugins may require ports to be added to the server.
