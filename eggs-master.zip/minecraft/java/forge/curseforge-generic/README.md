# Forge Generic

### This is a generic egg for curseforge modpacks

You will need to give it a modpack ID. The ID for sevtech-ages is `268208` for example.  
This can be found on the modpack page in the `About Project` section in the upper right corner.

This will grabe the latest release when the version is set to latest. 

It "should" grab versions of the pack based on the modpack version numbers