# Stationeers
Steam Description  
Construct and manage your own space station either by yourself in singleplayer or with friends online! Fully functioning atmospherics, science, power, engineering, medical, logic, and agricultural systems. Explore to find asteroids and construct elaborate factories to harvest your resources!

### Server Ports
Stationeers requires up to 2 ports

game port (default 27500)
Steam Query Ports (default 27015)


| Port    | default       |
|---------|---------------|
| Game    |     27500      |
| Query     |     27015     |