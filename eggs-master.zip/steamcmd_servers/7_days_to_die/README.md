# 7 Days to Die
Steam Description  
Set in a brutally unforgiving post-apocalyptic world overrun by the undead, 7 Days to Die is an open-world game that is a unique combination of first person shooter, survival horror, tower defense, and role-playing games. It presents combat, crafting, looting, mining, exploration, and character growth, in a way that has seen a rapturous response from fans worldwide. Play the definitive zombie survival sandbox RPG that came first. Navezgane awaits!

### Server Ports
7 Days to Die requires up to 6 ports

game ports (default 26900-26902)
remote control (default 8080, 8081)
allocs webmap (default 8082)

| Port    | default       |
|---------|---------------|
| Game    | 26900 - 26902 |
| RCON    | 8080 - 8081   |
| webmap  | 8082          |