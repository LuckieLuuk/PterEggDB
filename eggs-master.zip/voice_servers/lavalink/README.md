# Lavalink Server
### From their [Github](https://github.com/Frederikam/Lavalink)
Standalone audio sending node based on Lavaplayer and JDA-Audio. Allows for sending audio without it ever reaching any of your shards.

### Server Ports
Ports required to run the server in a table format.

| Port     | default  |
|----------|----------|
| Lavalink |  2333    |

#### Mods/Plugins may require ports to be added to the server.
