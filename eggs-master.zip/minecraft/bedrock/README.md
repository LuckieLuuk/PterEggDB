# Minecraft PE (bedrock edition)

#### Bedrock
[Minecraft Bedrock Server](https://minecraft.net/en-us/download/server/bedrock/)
The official Minecraft Bedrock (Formerly Minecraft Pocket Edition) server.

#### DragonProxy
[DragonProxy Github](https://github.com/DragonetMC/DragonProxy)
A proxy to allow Minecraft: Bedrock clients to connect to Minecraft: Java Edition servers.

#### Nukkit
[Nukkit GitHub](https://github.com/Nukkit/Nukkit)  
Nukkit is a Nuclear-Powered Server Software For Minecraft: Pocket Edition  

#### PocketMine MP
[PocketMine MP](https://github.com/pmmp/PocketMine-MP)  
A server software for Minecraft: Bedrock Edition in PHP  
